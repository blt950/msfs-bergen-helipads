Bergen Helipads created by blt950
 
Grønneviksøren Heliport (ENBG)
Sandviken Helipad (ENBI)
Bergen Haukeland Helipad (ENBX)

* * * Install * * * 
Place all 3 airports in your MSFS Community folder, in seperate folders.

* * * Feedback * * *
This is my first MSFS scenery and feedback is very welcome at flightsim.to

* * * Disclaimer * * * 
Do not modify, redistribute or reupload the content without written permission
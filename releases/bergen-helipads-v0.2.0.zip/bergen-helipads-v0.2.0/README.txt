Bergen Helipads created by blt950

Grønneviksøren Heliport (ENBG)
Sandviken Helipad (ENBI, but ENSA in MSFS because of duplicate ICAO)
Bergen Haukeland Helipad (ENBX)

* * * Install * * * 
Read install notes in description: https://flightsim.to/file/37736/bergen-helipads

* * * Feedback * * *
This is my first MSFS scenery and feedback is very welcome at flightsim.to

* * * Disclaimer * * * 
Do not modify, redistribute or reupload the content without written permission